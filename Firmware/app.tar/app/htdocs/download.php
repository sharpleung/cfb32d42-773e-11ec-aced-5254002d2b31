<?php session_start();?>
<?php include("check_user.inc");?>
<?php include("header.inc");?>
<title>����ҳ��</title>
<link href="./css/golbal.css" rel="stylesheet" type="text/css" />
<link href="./css/class.css" rel="stylesheet" type="text/css" />
<link href="./css/main.css" rel="stylesheet" type="text/css" />
<link href="./dtree/dtree.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="./dtree/dtree.js"></script>
<script type="text/javascript" src="./js/common.js"></script>
<script type="text/javascript" src="./js/Notice.js"></script>
<script type="text/javascript">
var Msg = new Notice();

function showMsg(status,text){
    if(Msg)
        Msg[status](text);
}
</script>
</head>
<body>
<div id="warper">
  <h1><?php echo "�����ļ�����" ?></h1>
  <br />
  <center>
    <form name="formInput" class="clear_patch" method="post" action="download_file.php" target="download_file">
      <table>
        <tr>
          <td>��ѡ����Ҫ���ص��ļ���</td>
          <td><select name="file_name">
              <option value="dev.conf">dev.conf</option>
              <option value="audiod.conf">audiod.conf</option>
              <option value="videod.conf">videod.conf</option>
              <option value="video_analyzer.conf">video_analyzer.conf</option>
              <option value="center.conf">center.conf</option>
              <option value="stream_switch.conf">stream_switch.conf</option>
              <option value="rtspserver.conf">rtspserver.conf</option>
              <option value="ifboard_type_map.conf">ifboard_type_map.conf</option>
              <option value="mainboard_type_map.conf">mainboard_type_map.conf</option>
              <option value="app.taz">app.taz</option>
              <option value="wav.tar.gz">wav.tar.gz</option>
            </select></td>
        </tr>
        <tr height="15"/>
        <tr>
          <td colspan="2" align="center"><button type="submit" class="clear_patch">����</button></td>
        </tr>
      </table>
    </form>
  </center>
<h1><?php echo "��Ƶ�ļ�����" ?></h1>
<div class="dtree">
    <p><a href="javascript: d.openAll();">ȫ��չ��</a> | <a href="javascript: d.closeAll();">ȫ������</a></p>
<?php
    //date_default_timezone_set("Asia/Chongqing");
    $id=0;
    function add_tree_node(&$id,$pid,$directory)
    {
        if(is_dir($directory))
        {
            //echo "$current_dir";
            //echo date("Y-m-d H:i:s");
            $file_array = array();
            $count=0;
            // get files
            $mydir=dir($directory);
            while( $file=$mydir->read() AND $count<10000 )
            {
                $file_array[$count] = $file;
                $count++;
            }
            $mydir->close();
            sort($file_array);
            $i = 0;
            while( $i<$count )
            {
                $file = $file_array[$i];
                $i++;
                $path = "$directory/$file";
                if(is_dir($path))
                {
                    if(($file!=".") AND ($file!="..") AND ($file!="lost+found"))
                    {
                        $id+=1;
                        //encode spaces
                        //$file =  rawurlencode($file);
                        // convert the + (this is one result from the function rawurlencode) in %20
                        //$url = str_replace('+' , '%20' , $file);
                        echo "d.add($id,$pid,'$file','','','','img/folder.gif');\n";
                        add_tree_node($id,$id,$path);
                    }
                }
                else
                {
                    $id+=1;
                    //$filetime=date("Y-m-d H:i:s",filectime($path));
                    //encode spaces
                    //$file =  rawurlencode($file);
                    // convert the + (this is one result from the function rawurlencode) in %20
                    $extend=substr(strrchr($file, '.'), 1);
                    $url = str_replace('+' , '%20' , $path);
                    if($extend=="dat")
                    {
                        $size=filesize($path);
                        if($size<1024)
                        {
                            $size_str = $size."B";
                        }
                        else if($size<1048576)
                        {
                            $size_str = round($size/1024,2)."K";
                        }
                        else
                        {
                            $size_str = round($size/1048576,2)."M";
                        }
                        echo "d.add($id,$pid,'$file      ------      $size_str','$url','','','img/page.gif');\n";
                    }
                }
            }
        }
    }
    echo "\n
    <script type=\"text/javascript\">\n
        <!--\n
        d = new dTree('d');\n
        d.add(0,-1,'disk');\n";
    add_tree_node($id,0,"mnt");
    echo "\n
         document.write(d);\n
        //-->\n
    </script>"
?>
</div>
  <iframe name="download_file" id="upload_file" class="hide" width="0" height="0"></iframe>
</div>



</body>
</html>
