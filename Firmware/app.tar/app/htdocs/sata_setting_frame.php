<?php session_start();?>
<?php include("check_user.inc");?>
<?php include("header.inc");?>
<title>����ҳ��</title>
<link href="./css/golbal.css" rel="stylesheet" type="text/css" />
<link href="./css/class.css" rel="stylesheet" type="text/css" />
<link href="./css/main.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="./js/common.js"></script>
<script type="text/javascript" src="./js/Validate.js"></script>
<script type="text/javascript">
var XMLHttp = null;//XMLHTTPRequest����
function checkInput(obj){
	var V = new Validate("formInput");
	
	V.checkEmpty({
		control:"baud_rate",
		msg:"�����ʲ���Ϊ��",
		err:V.showError
	});
	
	V.checkEmpty({
		control:"data_len",
		msg:"����λ����Ϊ��",
		err:V.showError
	});
	
	V.checkEmpty({
		control:"parity",
		msg:"��żУ��λ����Ϊ��",
		err:V.showError
	});
	
	V.checkEmpty({
		control:"stop_bit",
		msg:"ֹͣλ����Ϊ��",
		err:V.showError
	});
	
	V.checkEmpty({
		control:"dtr",
		msg:"DTR����Ϊ��",
		err:V.showError
	});
	
	V.checkEmpty({
		control:"rts",
		msg:"RTS����Ϊ��",
		err:V.showError
	});
	
	V.checkNum({
		control:"timeout",
		checkEmpty:true,
		msg:{
			empty:"�ύ��ʱʱ�䲻��Ϊ��",
			invalid:"���ܰ����������ַ�"
		},
		err:V.showError
	});
	
	V.checkNum({
		control:"buffer",
		checkEmpty:true,
		msg:{
			empty:"�������ݴ�С����Ϊ��",
			invalid:"���ܰ����������ַ�"
		},
		err:V.showError
	});
	
	if(V.pass)
		postInfo();
	
	return false;
}

function getInfo(){
	var num = Math.random();
	var params = 'interface=<?php echo $_GET["interface"];?>';
	params += '&CONFIG_PATH=' + document.formInput.config_path.value;
	if (null == XMLHttp){
		createXMLHTTP("xml");
	}
	ajaxSendRequest(XMLHttp,'./cgi-bin/get_com_cfg.cgi?' + num,params,setInfo);
}

function setInfo(xmlDoc){
	var oForm = document.formInput;
	var error = getTextNode(xmlDoc,"code")[0];
	if(error && error == 0){
		var rate = getNodeAttr(xmlDoc,"com","BAUD_RATE")[0];
		var data = getNodeAttr(xmlDoc,"com","DATA_LENGTH")[0];
		var parity = getNodeAttr(xmlDoc,"com","PARITY")[0];
		var bit = getNodeAttr(xmlDoc,"com","STOP_BITS")[0];
		var timeout = getNodeAttr(xmlDoc,"com","RECV_TIMEOUT")[0];
		var buffer = getNodeAttr(xmlDoc,"com","RECV_BUFFER_SIZE")[0];
		var dtr = getNodeAttr(xmlDoc,"com","DTR")[0];
		var rts = getNodeAttr(xmlDoc,"com","RTS")[0];
		oForm.baud_rate.value = rate;
		oForm.data_len.value = data;
		oForm.parity.value = parity.toUpperCase();
		oForm.stop_bit.value = bit;
		oForm.timeout.value = timeout || 50;
		oForm.buffer.value = buffer || 1024;
		oForm.dtr.value = dtr || "0";
		oForm.rts.value = rts || "0";
	} else 
		parent.Msg.fail("���ݻ�ȡʧ�ܣ�" + (getTextNode(xmlDoc,"desc")[0] || "δ֪����"));
}

function postInfo(){
	var oForm = document.formInput;
	var params = 'BAUD_RATE=' + oForm.baud_rate.value;
	params += '&DATA_LENGTH=' + oForm.data_len.value;
	params += '&PARITY=' + oForm.parity.value;
	params += '&STOP_BITS=' + oForm.stop_bit.value;
	params += '&RECV_TIMEOUT=' + oForm.timeout.value;
	params += '&RECV_BUFFER_SIZE=' + oForm.buffer.value;
	params += '&DTR=' + oForm.dtr.value;
	params += '&RTS=' + oForm.rts.value;
	params += '&interface=' + oForm.index.value;
	params += '&CONFIG_PATH=' + oForm.config_path.value;
	if (null == XMLHttp){
		createXMLHTTP("xml");
	}
	ajaxSendRequest(XMLHttp,'./cgi-bin/set_com_cfg.cgi',params,return_msg);	
}

function return_msg(xmlDoc){
	var errorCode = getTextNode(xmlDoc,"code")[0];
	var index = <?php echo $_GET["interface"];?> + 1;
	if(errorCode && errorCode == 0)
		parent.Msg.ok("����" + index + "�޸ĳɹ���");
	else
		parent.Msg.fail("����" + index + "�޸�ʧ�ܣ�" + (getTextNode(xmlDoc,"desc")[0] || "δ֪����"));
}
</script>
</head>
<body onLoad="setFocus();getInfo()">
<form name="formInput" onSubmit="return checkInput(this)">
  <input type="hidden" name="config_path" value="<?php echo $_SERVER["CONFIG_PATH"];?>" />
  <input type="hidden" name="index" value="<?php echo $_GET["interface"];?>" />
  <div><span>�����ʣ�</span>
    <select name="baud_rate" id="baud_rate">
      <option value="" selected="selected"></option>
      <option value="50">50 bps</option>
      <option value="75">75 bps</option>
      <option value="110">110 bps</option>
      <option value="134">134 bps</option>
      <option value="150">150 bps</option>
      <option value="200">200 bps</option>
      <option value="300">300 bps</option>
      <option value="600">600 bps</option>
      <option value="1200">1200 bps</option>
      <option value="1800">1800 bps</option>
      <option value="2400">2400 bps</option>
      <option value="4800">4800 bps</option>
      <option value="9600">9600 bps</option>
      <option value="19200">19200 bps</option>
      <option value="38400">38400 bps</option>
      <option value="57600">57600 bps</option>
      <option value="115200">115200 bps</option>
      <option value="230400">230400 bps</option>
    </select>
  </div>
  <div><span>����λ��</span>
    <select name="data_len" id="data_len">
      <option value="" selected="selected"></option>
      <option value="5">5 bits</option>
      <option value="6">6 bits</option>
      <option value="7">7 bits</option>
      <option value="8" >8 bits</option>
      <option value="9">9 bits</option>
    </select>
  </div>
  <div><span>��żУ��λ��</span>
    <select name="parity" id="parity">
      <option value="" selected="selected"></option>
      <option value="O">��У��/Odd</option>
      <option value="E">żУ��/Even</option>
      <option value="S">SpaceУ��/Space</option>
      <option value="M">MarkУ��/Mark</option>
      <option value="N">��У��/None</option>
    </select>
  </div>
  <div><span>ֹͣλ��</span>
    <select name="stop_bit" id="stop_bit">
      <option value="" selected="selected"></option>
      <option value="1">1 bit</option>
      <option value="1.5">1.5 bits</option>
      <option value="2">2 bits</option>
    </select>
  </div>
  <div><span>DTR��</span>
    <select name="dtr" id="dtr">
      <option value="" selected="selected"></option>
      <option value="0">����ʼ��</option>
      <option value="1">����ѹ</option>
      <option value="2">����ѹ</option>
    </select>
  </div>
  <div><span>RTS��</span>
    <select name="rts" id="rts">
      <option value="" selected="selected"></option>
      <option value="0">����ʼ��</option>
      <option value="1">����ѹ</option>
      <option value="2">����ѹ</option>
    </select>
  </div>
  <div><span>�ύ��ʱʱ�䣺</span>
    <input type="text" name="timeout" id="timeout" maxlength="6" />
    ���� </div>
  <div><span>�������ݴ�С��</span>
    <input type="text" name="buffer" id="buffer" maxlength="10" />
    Byte </div>
  <div class="last">
    <button type="submit">ȷ��</button>
  </div>
</form>
</body>
</html>
