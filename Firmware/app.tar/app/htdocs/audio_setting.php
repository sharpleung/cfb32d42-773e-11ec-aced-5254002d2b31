<?php session_start();?>
<?php include("check_user.inc");?>
<?php include("header.inc");?>
<title>����ҳ��</title>
<link href="./css/golbal.css" rel="stylesheet" type="text/css" />
<link href="./css/class.css" rel="stylesheet" type="text/css" />
<link href="./css/main.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="./js/common.js"></script>
<script type="text/javascript" src="./js/Notice.js"></script>
<script type="text/javascript" src="./js/Validate.js"></script>
<script type="text/javascript">
var Msg = new Notice();
var XMLHttp = null;//XMLHTTPRequest����

function checkInput(obj){
    var V = new Validate("formInput");

    V.checkEmpty({
        control:"talk_mode",
        msg:"�Խ���ռģʽ����Ϊ��",
        err:V.showError
    });

    V.checkEmpty({
        control:"enable",
        msg:"��˫�����ò���Ϊ��",
        err:V.showError
    });

    V.checkNum({
        control:"silence_value",
        checkEmpty:true,
        msg:{
            empty:"������ֵ����Ϊ��",
            invalid:"���ܰ����������ַ�"
        },
        err:V.showError
    });

    V.checkNum({
        control:"silence_last_time",
        checkEmpty:true,
        msg:{
            empty:"����������ʱ����Ϊ��",
            invalid:"���ܰ����������ַ�"
        },
        err:V.showError
    });

    if(V.pass)
        postInfo();

    return false;
}

function getInfo(){
    var num = Math.random();
    params = '&CONFIG_PATH=' + document.formInput.config_path.value;
    if (null == XMLHttp){
        createXMLHTTP("xml");
    }
    ajaxSendRequest(XMLHttp,'./cgi-bin/get_audio.cgi?' + num,params,setInfo);
}

function setInfo(xmlDoc){
    var oForm = document.formInput;
    var error = getTextNode(xmlDoc,"code")[0];
    if(error && error == 0){
        var talk_mode = getNodeAttr(xmlDoc,"audio","talk_mode")[0];
        var enable = getNodeAttr(xmlDoc,"audio","enable")[0];
        var silence_value = getNodeAttr(xmlDoc,"audio","silence_value")[0];
        var silence_last_time = getNodeAttr(xmlDoc,"audio","silence_last_time")[0];
        oForm.talk_mode.value = talk_mode;
        oForm.enable.value = enable;
        oForm.silence_value.value = silence_value;
        oForm.silence_last_time.value = silence_last_time;
    } else
        Msg.fail("���ݻ�ȡʧ�ܣ�" + (getTextNode(xmlDoc,"desc")[0] || "δ֪����"));
}

function postInfo(){
    var oForm = document.formInput;
    var params = '&talk_mode=' + oForm.talk_mode.value;
    params += '&enable=' + oForm.enable.value;
    params += '&silence_value=' + oForm.silence_value.value;
    params += '&silence_last_time=' + oForm.silence_last_time.value;
    params += '&CONFIG_PATH=' + oForm.config_path.value;

    if (null == XMLHttp){
        createXMLHTTP("xml");
    }
    ajaxSendRequest(XMLHttp,'./cgi-bin/set_audio.cgi',params,return_msg);
}

function return_msg(xmlDoc){
    var errorCode = getTextNode(xmlDoc,"code")[0];
    if(errorCode && errorCode == 0)
        Msg.ok("��Ƶ�����޸ĳɹ���");
    else
        Msg.fail("��Ƶ�����޸�ʧ�ܣ�code=" + errorCode + "  ������" + (getTextNode(xmlDoc,"desc")[0] || "δ֪����"));
}
</script>
</head>
<body onLoad="setFocus();getInfo();">
<div id="warper">
  <h1><?php echo($_GET["name"]) ?></h1>
  <form name="formInput" onSubmit="return checkInput(this)">
    <input type="hidden" name="config_path" value="<?php echo $_SERVER["CONFIG_PATH"];?>" />
    <div class="clear"><span>�Խ���ռģʽ</span>
        <select name="talk_mode" id="talk_mode" >
            <option value="" selected="selected"></option>
            <option value="0">������ռ</OPTION>
            <option value="1">������ռ</option>
        </select>
    </div>
    <div class="clear"><span>��˫�����ã�</span>
        <select name="enable" id="enable" >
            <option value="" selected="selected"></option>
            <option value="0">������</OPTION>
            <option value="1">����</option>
        </select>
    </div>
    <div><span>������ֵ��</span>
      <input type="text" name="silence_value" id="silence_value" maxlength="32"/>
    </div>
    <div><span>����������ʱ��</span>
      <input type="text" name="silence_last_time" id="silence_last_time" maxlength="32"/>����
    </div>
    <div class="last">
      <button type="submit">ȷ��</button>
    </div>
  </form>
</div>
</body>
</html>
