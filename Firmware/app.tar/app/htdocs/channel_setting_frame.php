<?php session_start();?>
<?php include("check_user.inc");?>
<?php include("header.inc");?>
<?php include("function.php");?>
<?php
	$totle = get_tab_num("channel");
?>
<title>����ҳ��</title>
<link href="./css/golbal.css" rel="stylesheet" type="text/css" />
<link href="./css/class.css" rel="stylesheet" type="text/css" />
<link href="./css/main.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="./js/common.js"></script>
<script type="text/javascript" src="./js/Validate.js"></script>
<script type="text/javascript">
var XMLHttp = null;//XMLHTTPRequest����
function checkInput(obj){
	var V = new Validate("formInput");
	
	V.checkEmpty({
		control:"isolate",
		msg:"����״̬����Ϊ��",
		err:V.showError
	});
	
	V.checkEmpty({
		control:"alarm_type",
		msg:"�������Ͳ���Ϊ��",
		err:V.showError
	});
	
	V.checkEmpty({
		control:"status_type",
		msg:"״̬�ı����Ͳ���Ϊ��",
		err:V.showError
	});
	
	var el = V.oForm.status_type;
	V.checkNum({
		control:"status_val",
		checkEmpty:true,
		msg:{
			empty:el.options[el.selectedIndex].text + "����Ϊ��",
			invalid:"���ܰ����������ַ�"
		},
		err:V.showError
	});
	
	V.checkNum({
		control:"status_delay",
		checkEmpty:true,
		msg:{
			empty:"��������ʱ�䲻��Ϊ��",
			invalid:"���ܰ����������ַ�"
		},
		err:V.showError
	});
	
	V.checkNum({
		control:"off_delay",
		checkEmpty:true,
		msg:{
			empty:"�ָ���ʱʱ�䲻��Ϊ��",
			invalid:"���ܰ����������ַ�"
		},
		err:V.showError
	});
	
	if(V.pass)
		postInfo();
	
	return false;
}

function getInfo(){
	var num = Math.random();
	var params = 'interface=<?php echo $_GET["interface"];?>';
	params += '&CONFIG_PATH=' + document.formInput.config_path.value;
	params += '&TYPE=' + document.formInput.ch_type.value;
	params += '&NUM=' + <?php echo $totle;?>;
	if (null == XMLHttp){
		createXMLHTTP("xml");
	}
	ajaxSendRequest(XMLHttp,'./cgi-bin/get_ch_cfg.cgi?' + num,params,setInfo);
}

function setInfo(xmlDoc){
	var oForm = document.formInput;
	var error = getTextNode(xmlDoc,"code")[0];
	if(error && error == 0){
		var panel = getNodeAttr(xmlDoc,"channel","PANELNAME")[0]
		var isolate = getNodeAttr(xmlDoc,"channel","DISABLE")[0];
		var alarm_type = getNodeAttr(xmlDoc,"channel","ALARMON")[0];
		var status_count = getNodeAttr(xmlDoc,"channel","STABLE_COUNT")[0];
		var status_time = getNodeAttr(xmlDoc,"channel","STABLE_TIME")[0];
		var status_delay = getNodeAttr(xmlDoc,"channel","LONG_PRESS_TIME")[0];
		var off_delay = getNodeAttr(xmlDoc,"channel","ALARM_OFF_DELAY")[0];
		var status_type = "";
		if(+status_count > 0 && +status_time > 0){
			parent.Msg.fail("�����ѻٻ�!");	
			return;
		}
		status_type = status_count > 0?"STABLE_COUNT":status_time > 0?"STABLE_TIME":"STABLE_NONE";	
		oForm.panel.value = panel;
		oForm.isolate.value = isolate;
		oForm.alarm_type.value = alarm_type;
		oForm.status_type.value = status_type;
		showSelect(status_type);
		oForm.status_val.value = getNodeAttr(xmlDoc,"channel",status_type)[0];
		oForm.status_delay.value = status_delay;
		oForm.off_delay.value = off_delay;
	} else 
		parent.Msg.fail("���ݻ�ȡʧ�ܣ�" + (getTextNode(xmlDoc,"desc")[0] || "δ֪����"));
}

function postInfo(){
	var oForm = document.formInput;
	var params = 'DISABLE=' + oForm.isolate.value;
	params += '&ALARMON=' + oForm.alarm_type.value;
	if(oForm.status_type.value != "STABLE_NONE"){
		params += '&' + oForm.status_type.value + '=' + oForm.status_val.value;
		params += '&' + oForm.status_val.getAttribute("disable_status") + '=0';
	} else {
		params += '&STABLE_COUNT=' + 0;
		params += '&STABLE_TIME=' + 0;	
	}
	params += '&LONG_PRESS_TIME=' + oForm.status_delay.value;
	params += '&ALARM_OFF_DELAY=' + oForm.off_delay.value;
	params += '&interface=' + oForm.index.value;
	params += '&CONFIG_PATH=' + oForm.config_path.value;
	params += '&TYPE=' + oForm.ch_type.value;
	params += '&PANELNAME=' + oForm.panel.value;
	if (null == XMLHttp){
		createXMLHTTP("xml");
	}
	ajaxSendRequest(XMLHttp,'./cgi-bin/set_ch_cfg.cgi',params,return_msg);	
}

function return_msg(xmlDoc){
	var errorCode = getTextNode(xmlDoc,"code")[0];
	if(errorCode && errorCode == 0)
		parent.Msg.ok("<?php echo $_GET["title"]?>ͨ���޸ĳɹ���");
	else 
		parent.Msg.fail("<?php echo $_GET["title"]?>ͨ���޸�ʧ�ܣ�" + (getTextNode(xmlDoc,"desc")[0] || "δ֪����"));

}

function showSelect(val){
	if(val){
		switch(val){
			case "STABLE_COUNT"	:
				getId("unit").innerHTML = "��";
				getId("input").className = "show";
				getId("status_val").setAttribute("disable_status","STABLE_TIME");
				break;
			case "STABLE_TIME"	:
				getId("unit").innerHTML = "����";
				getId("input").className = "show";
				getId("status_val").setAttribute("disable_status","STABLE_COUNT");
				break;	
			default:
				getId("status_val").value = "";
				getId("input").className = "hide";
				getId("status_val").setAttribute("disable_status","");
		}	
	} else {
		getId("input").className = "hide";	
		getId("status_val").value = "";
	}
}
</script>
</head>
<body onLoad="setFocus();getInfo();">
<form name="formInput" onSubmit="return checkInput(this)">
  <input type="hidden" name="config_path" value="<?php echo $_SERVER["CONFIG_PATH"];?>" />
  <input type="hidden" name="index" value="<?php echo $_GET["interface"];?>" />
  <input type="hidden" name="ch_type" value="<?php echo $_GET["type"];?>" />
  <input type="hidden" name="panel" value="" />
  <div><span class="width_110">����״̬��</span>
    <select id="isolate" name="isolate">
      <option value="" selected="selected"></option>
      <option value="0">������</option>
      <option value="1">����</option>
    </select>
  </div>
  <div><span class="width_110">�������ͣ�</span>
    <select id="alarm_type" name="alarm_type">
      <option value="" selected="selected"></option>
      <option value="0">��·����</option>
      <option value="1">���ձ���</option>
    </select>
  </div>
  <div><span class="width_110">״̬�ı����ͣ�</span>
    <select id="status_type" name="status_type" onChange="showSelect(this.value)">
      <option value="" selected="selected"></option>
      <option value="STABLE_COUNT">ͨ��ɨ������ı�</option>
      <option value="STABLE_TIME">ͨ������ʱ��ı�</option>
      <option value="STABLE_NONE">��ͨ���κη���ֱ�Ӹı�</option>
    </select>
  </div>
  <div class="hide" id="input"><span class="width_110">&nbsp;</span>
    <input type="text" name="status_val" id="status_val" maxlength="6"/>
    <span id="unit"></span> </div>
  <div><span class="width_110">��������ʱ�䣺</span>
    <input type="text" name="status_delay" id="status_delay" maxlength="6" />
    ���� </div>
  <div><span class="width_110">�ָ���ʱʱ�䣺</span>
    <input type="text" name="off_delay" id="off_delay" maxlength="6" />
    ���� </div>
  <div class="last">
    <button class="mar_l115" type="submit">ȷ��</button>
  </div>
</form>
</body>
</html>
