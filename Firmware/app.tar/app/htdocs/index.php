<?php include("header.inc");?>
<?php
	$path = $_SERVER["CONFIG_PATH"];
	exec("cat " . $path . "/web_profile.conf",$res);
	$model = preg_replace("/\s+/"," ",trim($res[1]));
	$model = explode(" ",$model);
	$model = $model[1];
?>
<title>����ҳ��</title>
<link href="css/golbal.css" rel="stylesheet" type="text/css" />
<link href="css/class.css" rel="stylesheet" type="text/css" />
<link href="css/login.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="./js/common.js"></script>
<!--[if lt IE 7]>
	<script type="text/javascript" src="js/DD_belatedPNG_0.0.8a.js"></script>
    <script type="text/javascript">
    	DD_belatedPNG.fix('#header img');
    </script>
<![endif]-->
</head>
<body onLoad="setFocus()">
<div id="layout">
  <div id="header">
    <div><a href="http://www.thinker.com.cn"  target="_blank"><img src="images/logo.png" title="Thinker����Ƽ�" alt="Thinker����Ƽ�" /></a><span>Thinker-<?php echo $model?> Configuration System</span></div>
  </div>
  <div id="middle">
    <table width="100%" height="100%">
      <tr>
        <td valign="middle"><img src="images/index_bg.jpg" width="419" height="259" alt="" /></td>
        <td width="250"><table width="100%" height="100%">
            <tr>
              <td height="125">&nbsp;</td>
            </tr>
            <tr>
              <td><form name="frm_login" method="post" action="login.php">
                  <div><span>�û�����</span>
                    <input class="input" type="text" name="user_name" autocomplete="off">
                  </div>
                  <div><span>�ܡ��룺</span>
                    <input class="input" name="user_password" type="password" maxlength="16" autocomplete="off">
                  </div>
                  <div align="right">
                    <input class="btn" type="submit" name="submit" value="�ύ">
                  </div>
                </form></td>
            </tr>
          </table></td>
      </tr>
    </table>
  </div>
  <div id="footer">
    <div>&nbsp;</div>
    <p>E-mail��<a href="http://www.thinker.com.cn" target="_blank">http://www.thinker.com.cn</a> Tel��86-4008866343 Fax��86-20-85566445 COMPANY�����ݴ���Ƽ��ɷ����޹�˾</p>
  </div>
</div>
</body>
</html>