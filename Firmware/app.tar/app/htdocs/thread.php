<?php session_start();?>
<?php include("check_user.inc");?>
<?php include("header.inc");?>
<title>����ҳ��</title>
<link href="./css/golbal.css" rel="stylesheet" type="text/css" />
<link href="./css/class.css" rel="stylesheet" type="text/css" />
<link href="./css/main.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="./js/common.js"></script>
<script type="text/javascript" src="./js/Notice.js"></script>
<script type="text/javascript">
var Msg = new Notice();
<?php
	$is_submit = $_POST["is_submit"];
	if($is_submit == "1"){
		 system("restartapp > /dev/null 2>&1");
?>
		setTimeout(function(){
			Msg.ok("���������ɹ���");					
		},0);
<?php
	}
?>
</script>
</head>
<body>
<div id="warper">
  <h1><?php echo($_GET["name"])?></h1>
  <br />
  <center>
    <form class="clear_patch" action="thread.php?name=��������" method="post" >
      <input type="hidden" name="is_submit" value="1" />
      <button type="submit" class="clear_patch">����</button>
    </form>
  </center>
</div>
</body>
</html>
