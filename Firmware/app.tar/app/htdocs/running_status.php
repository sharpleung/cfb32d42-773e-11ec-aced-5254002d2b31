<?php session_start();?>
<?php include("check_user.inc");?>
<?php include("header.inc");?>
<?php date_default_timezone_set('Asia/Shanghai');?>
<?php
	$path = $_SERVER["CONFIG_PATH"];
	exec("cat " . $path . "/web_profile.conf",$res);
	$mianboard = preg_replace("/\s+/"," ",trim($res[2]));
	$ifboard = preg_replace("/\s+/"," ",trim($res[3]));
	$mianboard = explode(" ",$mianboard);
	$ifboard = explode(" ",$ifboard);
	$mianboard = $mianboard[1];
	$ifboard = $ifboard[1];
?>
<title>����ҳ��</title>
<link href="./css/golbal.css" rel="stylesheet" type="text/css" />
<link href="./css/class.css" rel="stylesheet" type="text/css" />
<link href="./css/main.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="./js/common.js"></script>
<script type="text/javascript" src="./js/Notice.js"></script>
<script type="text/javascript">
var Msg = new Notice();
var XMLHttp = null;

function getSysInfo(){
	var num = Math.random();
	createXMLHTTP("xml");
	ajaxSendRequest(XMLHttp,'./cgi-bin/get_sys_resource.cgi?' + num,null,setSysInfo);
}

function getVideoInfo(){
	var num = Math.random();
	createXMLHTTP("html");
	ajaxSendRequest(XMLHttp,'./get_video.php?' + num,null,function(){setVieoInfo(XMLHttp)});	
}

function setSysInfo(xmlDoc){
	var error = getTextNode(xmlDoc,"code")[0];
	if(error && error == 0){
		var disks = getNode(xmlDoc,"partition");
		var table = getId("partition");
		var l = table.rows.length;
		table.deleteRow(l - 1);
		getId("cpu").innerHTML = getTextNode(xmlDoc,"cpu")[0] + "%";
		getId("mem").innerHTML = getTextNode(xmlDoc,"mem")[0] + "%";	
		for(var i = 0,len = disks.length; i < len; i++){
			var row = table.insertRow(l - 1 + i);
			row.insertCell(0).innerHTML = disks[i].getAttribute("path");
			row.insertCell(1).innerHTML = disks[i].getAttribute("size");
			row.insertCell(2).innerHTML = disks[i].getAttribute("free");
			row.insertCell(3).innerHTML = disks[i].getAttribute("userate");
		}
	} else 
		Msg.fail("���ݻ�ȡʧ�ܣ�" + (getTextNode(xmlDoc,"desc")[0] || "δ֪����"));
}

function setVieoInfo(request){
	var text = 	request.responseText.trim();
	var obj = eval("(" + text + ")");
	if(obj.error === undefined){
		var table = getId("video");
		var l = table.rows.length;
		table.deleteRow(l - 1);
		getId("compress").innerHTML = (obj.TIMESTAMP || "")?obj.TIMESTAMP + "s" + " (��Լ��" + getRunTime(obj.TIMESTAMP) + ")":"";
		getId("dsp").innerHTML = (obj.DSP_LOAD || "")?obj.DSP_LOAD + "%":"";
		
		for(var i = 0; i < 4; i++){
			var row = table.insertRow(l - 1 + i);
			row.insertCell(0).innerHTML = "ͨ��" + (i + 1);
			row.insertCell(1).innerHTML = obj["CH" + i + "_PACKET"] || "";
			row.insertCell(2).innerHTML = obj["CH" + i + "_BYTE"] || "";
			row.insertCell(3).innerHTML = obj["CH" + i + "_PACKET_RATE"] || "";
			row.insertCell(4).innerHTML = obj["CH" + i + "_BYTE_RATE"] || "";
			row.insertCell(5).innerHTML = obj["CH" + i + "_BIT_RATE"] || "";
		}
	} else
		Msg.fail(obj.error);
}

function getRunTime(num){
	var day = parseInt(num/86400);
	var hour = parseInt((num-day*86400)/3600);
	var minu = parseInt((num-day*86400 - hour*3600)/60);
	var sec = num-(day*86400 + hour*3600 + minu*60);
	return day + "��" + hour + "Сʱ" + minu + "��" + sec + "��";
}

function fomatNum(num){
	return num.toString().length == 1?"0"+num:num;
}

function uptime(){
	var el = getId("current_time");
	if(el)
		el.innerHTML = "���ڸ��·�����ʱ�䡭��";
		
	var date = new Date();
	var year = date.getFullYear();
	var month = fomatNum(date.getMonth() + 1);
	var day = fomatNum(date.getDate());
	var hour = fomatNum(date.getHours());
	var minus = fomatNum(date.getMinutes());
	var sec = fomatNum(date.getSeconds());
	var params = "current_time=" + year + "-" + month + "-" + day + " " + hour + ":" + minus + ":" + sec;
	var num = Math.random();
	createXMLHTTP("html");
	ajaxSendRequest(XMLHttp,'uptime.php?' + num,params,refreshTime);
}

function refreshTime(){
	var text = 	XMLHttp.responseText.trim();
	var el = getId("current_time");
	if(el)
		el.innerHTML = text.replace(/\s{2,}/g , " ");
}
</script>
</head>
<body onLoad="getSysInfo();getVideoInfo()">
<div id="warper">
  <h1><?php echo($_GET["name"])?></h1>
  <div class="status">
    <p align="right">
      <input type="button" value="ȫ��ˢ��" onClick="location.reload()" />
    </p>
    <table cellpadding="0" cellspacing="1">
      <tr>
        <th colspan="3">�豸�����ͺ���Ϣ</th>
      </tr>
      <tr>
        <td>�ͺ�</td>
        <td>Kernel�汾</td>
        <td>Ӧ�ó���汾</td>
      </tr>
      <tr>
        <td><?php system("cat /usr/local/os/model");?></td>
        <td><?php system("cat /etc/baseos");?></td>
        <td><?php system("cat /usr/local/app/version");?></td>
      </tr>
    </table>
    <table cellpadding="0" cellspacing="1">
      <tr>
        <th colspan="2">�豸�忨�ͺ���Ϣ</th>
      </tr>
      <tr>
        <td>���忨�ͺ�</td>
        <td>�ӿڰ忨�ͺ�</td>
      </tr>
      <tr>
        <td><?php echo $mianboard;?></td>
        <td><?php echo $ifboard;?></td>
      </tr>
    </table>
    <table cellpadding="0" cellspacing="1">
      <tr>
        <th>��������ǰʱ��</th>
      </tr>
      <tr>
        <td><span class="uptime" title="���·�����ʱ��Ϊ��ǰʱ��" onClick="uptime()">���·�������ǰʱ��</span><span id="current_time"><?php
	  exec("uptime",$res1);
	  $str = preg_replace ("/(,\s*\d\s*users)?,\s*load.+$/i","",$res1[0]);
	  if(strlen($str) > 0)
		echo date("Y-m-d ") . $str;
	  else
	  	echo date("Y-m-d H:i:s");
	?></span></td>
      </tr>
    </table>
    <table cellpadding="0" cellspacing="1">
      <tr>
        <th>CPUʹ����Ϣ</th>
      </tr>
      <tr>
        <td>ʹ����</td>
      </tr>
      <tr>
        <td id="cpu">���ڼ�����Ϣ...</td>
      </tr>
    </table>
    <table cellpadding="0" cellspacing="1">
      <tr>
        <th>�ڴ�ʹ����Ϣ</th>
      </tr>
      <tr>
        <td>ʹ����</td>
      </tr>
      <tr>
        <td id="mem">���ڼ�����Ϣ...</td>
      </tr>
    </table>
    <table id="partition" cellpadding="0" cellspacing="1">
      <tr>
        <th colspan="4">����ʹ����Ϣ</th>
      </tr>
      <tr>
        <td>���̷���</td>
        <td>������С(M)</td>
        <td>����ʣ��ռ�(M)</td>
        <td>ʹ����</td>
      </tr>
      <tr>
        <td colspan="4">���ڼ�����Ϣ...</td>
      </tr>
    </table>
    <table id="video" cellpadding="0" cellspacing="1">
      <tr>
        <th colspan="6">��Ƶʹ����Ϣ</th>
      </tr>
      <tr>
        <td colspan="6">��Ƶѹ����������ʱ��</td>
      </tr>
      <tr>
        <td id="compress" colspan="6">���ڼ�����Ϣ...</td>
      </tr>
      <tr>
        <td colspan="6">DSPʹ����</td>
      </tr>
      <tr>
        <td id="dsp" colspan="6">���ڼ�����Ϣ...</td>
      </tr>
      <tr>
        <td>��Ƶͨ��</td>
        <td>�Ѵ������ݰ�</td>
        <td>�Ѳ����ֽ���</td>
        <td>֡��</td>
        <td>����(Byte)</td>
        <td>����(Bit)</td>
      </tr>
      <tr>
        <td colspan="6">���ڼ�����Ϣ...</td>
      </tr>
    </table>
    <p align="right">
      <input type="button" value="ȫ��ˢ��" onClick="location.reload()" />
    </p>
  </div>
</div>
</body>
</html>
