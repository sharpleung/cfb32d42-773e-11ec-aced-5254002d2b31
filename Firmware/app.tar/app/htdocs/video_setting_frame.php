<?php session_start();?>
<?php include("check_user.inc");?>
<?php include("header.inc");?>
<?php include("function.php");?>
<?php
    $tab_num = get_tab_num("video");
?>
<title>����ҳ��</title>
<link href="./css/golbal.css" rel="stylesheet" type="text/css" />
<link href="./css/class.css" rel="stylesheet" type="text/css" />
<link href="./css/main.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="./js/common.js"></script>
<script type="text/javascript" src="./js/Validate.js"></script>
<script type="text/javascript">
var XMLHttp = null;//XMLHTTPRequest����

function checkInput(obj){
    var V = new Validate("formInput");

    V.checkNum({
        control:"bandwidth",
        checkEmpty:true,
        msg:{
            empty:"��������Ϊ��",
            invalid:"���ܰ����������ַ�"
        },
        err:V.showError
    });

    if(V.pass)
        postInfo();

    return false;
}

function getInfo(){
    var num = Math.random();
    params = '&CONFIG_PATH=' + document.formInput.config_path.value;
    if (null == XMLHttp){
        createXMLHTTP("xml");
    }
    ajaxSendRequest(XMLHttp,'./cgi-bin/get_video_cfg.cgi?' + num,params,setInfo);
}

function setInfo(xmlDoc){
    var tabs = <?php echo $tab_num?>;
    var oForm = document.formInput;
    var index = +oForm.index.value + 1;
    var error = getTextNode(xmlDoc,"code")[0];
    if(error && error == 0){
        var otherBd = {};
        var otherFr = {};
        var otherIfr ={};
        var otherFrameDelayCount ={};
        var otherTimeDispOpt ={};
        var otherTimeX ={};
        var otherTimeY ={};
        var otherChanName ={};
        var otherChanNameX ={};
        var otherChanNameY ={};
        var otheryuvEnable ={};
        var otheryuvSkipCount ={};
        var other_record_enable ={};
        var position, bandwidth, frameRate, iFrameRate ,frame_delay_count ,timeDispOption;
        var timeX ,timeY ,channelName, chanNameX, chanNameY;
        var yuvEnable ,yuvSkipCount ,recordEnableOption;
        position = getNodeAttr(xmlDoc,"video","POSITION")[0];
        for(var i = 1; i <= tabs; i++){
            if(i == index){
                bandwidth = getNodeAttr(xmlDoc,"video","BANDWIDTH" + index)[0];
                frameRate = getNodeAttr(xmlDoc,"video","FRAMERATE" + index)[0];
                iFrameRate = getNodeAttr(xmlDoc,"video","INTRAFRAMEINTERVAL" + index)[0];
                frame_delay_count = getNodeAttr(xmlDoc,"video","DELAY_FRAME_COUNT" + index)[0];
                timeDispOption = getNodeAttr(xmlDoc,"video","DISPLAY_TIME_OPTION" + index)[0];
                timeX = getNodeAttr(xmlDoc,"video","DISPLAY_TIME_X" + index)[0];
                timeY = getNodeAttr(xmlDoc,"video","DISPLAY_TIME_Y" + index)[0];
                channelName = getNodeAttr(xmlDoc,"video","CHANNEL_NAME" + index)[0];
                chanNameX = getNodeAttr(xmlDoc,"video","DISPLAY_CHANNEL_NAME_X" + index)[0];
                chanNameY = getNodeAttr(xmlDoc,"video","DISPLAY_CHANNEL_NAME_Y" + index)[0];
                yuvEnable = getNodeAttr(xmlDoc,"video","RAW_FRAME_WRITE" + index)[0];
                yuvSkipCount = getNodeAttr(xmlDoc,"video","RAW_FRAME_SKIP_COUNT" + index)[0];
                recordEnableOption = getNodeAttr(xmlDoc,"video","RECORD_ENABLED" + index)[0];
            } else {
                otherBd["BANDWIDTH" + i] = getNodeAttr(xmlDoc,"video","BANDWIDTH" + i)[0];
                otherFr["FRAMERATE" + i] = getNodeAttr(xmlDoc,"video","FRAMERATE" + i)[0];
                otherIfr["INTRAFRAMEINTERVAL" + i] = getNodeAttr(xmlDoc,"video","INTRAFRAMEINTERVAL" + i)[0];
                otherFrameDelayCount["DELAY_FRAME_COUNT" + i] = getNodeAttr(xmlDoc,"video","DELAY_FRAME_COUNT" + i)[0];
                otherTimeDispOpt["DISPLAY_TIME_OPTION" + i] = getNodeAttr(xmlDoc,"video","DISPLAY_TIME_OPTION" + i)[0];
                otherTimeX["DISPLAY_TIME_X" + i] = getNodeAttr(xmlDoc,"video","DISPLAY_TIME_X" + i)[0];
                otherTimeY["DISPLAY_TIME_Y" + i] = getNodeAttr(xmlDoc,"video","DISPLAY_TIME_Y" + i)[0];
                otherChanName["CHANNEL_NAME" + i] = getNodeAttr(xmlDoc,"video","CHANNEL_NAME" + i)[0];
                otherChanNameX["DISPLAY_CHANNEL_NAME_X" + i] = getNodeAttr(xmlDoc,"video","DISPLAY_CHANNEL_NAME_X" + i)[0];
                otherChanNameY["DISPLAY_CHANNEL_NAME_Y" + i] = getNodeAttr(xmlDoc,"video","DISPLAY_CHANNEL_NAME_Y" + i)[0];
                otheryuvEnable["RAW_FRAME_WRITE" + i] = getNodeAttr(xmlDoc,"video","RAW_FRAME_WRITE" + i)[0];
                otheryuvSkipCount["RAW_FRAME_SKIP_COUNT" + i] = getNodeAttr(xmlDoc,"video","RAW_FRAME_SKIP_COUNT" + i)[0];
                other_record_enable["RECORD_ENABLED" + i] = getNodeAttr(xmlDoc,"video","RECORD_ENABLED" + i)[0];
            }
        }
        for(var i in otherBd)
            oForm.other_bandwidth.value += i + ":" + otherBd[i] + ",";

        for(var i in otherFr)
            oForm.other_frame_rate.value += i + ":" + otherFr[i] + ",";

        for(var i in otherIfr)
            oForm.other_i_frame_rate.value += i + ":" + otherIfr[i] + ",";

        for(var i in otherFrameDelayCount)
            oForm.other_frame_delay_count.value += i + ":" + otherFrameDelayCount[i] + ",";

        for(var i in otherTimeDispOpt)
            oForm.other_time_option.value += i + ":" + otherTimeDispOpt[i] + ",";

        for(var i in otherTimeX)
            oForm.other_time_x.value += i + ":" + otherTimeX[i] + ",";

        for(var i in otherTimeY)
            oForm.other_time_y.value += i + ":" + otherTimeY[i] + ",";

        for(var i in otherChanName)
            oForm.other_chan_name.value += i + ":" + otherChanName[i] + ",";

        for(var i in otherChanNameX)
            oForm.other_chan_name_x.value += i + ":" + otherChanNameX[i] + ",";

        for(var i in otherChanNameY)
            oForm.other_chan_name_y.value += i + ":" + otherChanNameY[i] + ",";

        for(var i in otheryuvEnable)
            oForm.other_yuv_enable.value += i + ":" + otheryuvEnable[i] + ",";

        for(var i in otheryuvSkipCount)
            oForm.other_yuv_skip_count.value += i + ":" + otheryuvSkipCount[i] + ",";

        for(var i in other_record_enable)
            oForm.other_record_enable.value += i + ":" + other_record_enable[i] + ",";

        oForm.position.value = position || "10";
        oForm.bandwidth.value = bandwidth || "";
        oForm.frame_rate.value = frameRate || "";
        oForm.i_frame_rate.value = iFrameRate || "";
        oForm.frame_delay_count.value = frame_delay_count || "0";
        oForm.timeOption.value = timeDispOption || "1";
        oForm.timeX.value = timeX || "5";
        oForm.timeY.value = timeY || "5";
        oForm.chanName.value = channelName || "";
        oForm.chanNameX.value = chanNameX || "5";
        oForm.chanNameY.value = chanNameY || "265";
        oForm.rawEnableOption.value = yuvEnable || "1";
        oForm.yuv_frame_skip.value = yuvSkipCount || "24";
        oForm.recordEnableOption.value = recordEnableOption || "0";
    } else
        parent.Msg.fail("���ݻ�ȡʧ�ܣ�" + (getTextNode(xmlDoc,"desc")[0] || "δ֪����"));
}

function postInfo(){
    var oForm = document.formInput;
    var index = +oForm.index.value + 1;
    var otherBd = oForm.other_bandwidth.value.split(",");
    var otherFr = oForm.other_frame_rate.value.split(",");
    var otherIfr = oForm.other_i_frame_rate.value.split(",");
    var otherFrameDelayCount = oForm.other_frame_delay_count.value.split(",");
    var otherTimeDispOpt = oForm.other_time_option.value.split(",");
    var otherTimeX = oForm.other_time_x.value.split(",");
    var otherTimeY = oForm.other_time_y.value.split(",");
    var otherChanName = oForm.other_chan_name.value.split(",");
    var otherChanNameX = oForm.other_chan_name_x.value.split(",");
    var otherChanNameY = oForm.other_chan_name_y.value.split(",");
    var otheryuvEnable = oForm.other_yuv_enable.value.split(",");
    var otheryuvSkipCount = oForm.other_yuv_skip_count.value.split(",");
    var other_record_enable = oForm.other_record_enable.value.split(",");

    var params = 'POSITION' + '=' + oForm.position.value;
    params += '&BANDWIDTH' + index + '=' + oForm.bandwidth.value;
    params += '&FRAMERATE' + index + "=" + oForm.frame_rate.value;
    params += '&INTRAFRAMEINTERVAL' + index + "=" + oForm.i_frame_rate.value;
    params += '&DELAY_FRAME_COUNT' + index + "=" + oForm.frame_delay_count.value;
    params += '&DISPLAY_TIME_OPTION' + index + "=" + oForm.timeOption.value;
    params += '&DISPLAY_TIME_X' + index + "=" + oForm.timeX.value;
    params += '&DISPLAY_TIME_Y' + index + "=" + oForm.timeY.value;
    params += '&CHANNEL_NAME' + index + "=" + oForm.chanName.value;
    params += '&DISPLAY_CHANNEL_NAME_X' + index + "=" + oForm.chanNameX.value;
    params += '&DISPLAY_CHANNEL_NAME_Y' + index + "=" + oForm.chanNameY.value;
    params += '&RAW_FRAME_WRITE' + index + "=" + oForm.rawEnableOption.value;
    params += '&RAW_FRAME_SKIP_COUNT' + index + "=" + oForm.yuv_frame_skip.value;
    params += '&RECORD_ENABLED' + index + "=" + oForm.recordEnableOption.value;
    for(var i = 0; i < otherBd.length; i++){
        if(otherBd[i]){
            var arr = otherBd[i].split(":");
            params += '&' + arr[0] + '=' + arr[1];
        }
    }
    for(var i = 0; i < otherFr.length; i++){
        if(otherFr[i]){
            var arr = otherFr[i].split(":");
            params += '&' + arr[0] + '=' + arr[1];
        }
    }
    for(var i = 0; i < otherIfr.length; i++){
        if(otherIfr[i]){
            var arr = otherIfr[i].split(":");
            params += '&' + arr[0] + '=' + arr[1];
        }
    }
    for(var i = 0; i < otherFrameDelayCount.length; i++){
        if(otherFrameDelayCount[i]){
            var arr = otherFrameDelayCount[i].split(":");
            params += '&' + arr[0] + '=' + arr[1];
        }
    }
    for(var i = 0; i < otherTimeDispOpt.length; i++){
        if(otherTimeDispOpt[i]){
            var arr = otherTimeDispOpt[i].split(":");
            params += '&' + arr[0] + '=' + arr[1];
        }
    }
    for(var i = 0; i < otherTimeX.length; i++){
        if(otherTimeX[i]){
            var arr = otherTimeX[i].split(":");
            params += '&' + arr[0] + '=' + arr[1];
        }
    }
    for(var i = 0; i < otherTimeY.length; i++){
        if(otherTimeY[i]){
            var arr = otherTimeY[i].split(":");
            params += '&' + arr[0] + '=' + arr[1];
        }
    }
    for(var i = 0; i < otherChanName.length; i++){
        if(otherChanName[i]){
            var arr = otherChanName[i].split(":");
            params += '&' + arr[0] + '=' + arr[1];
        }
    }
    for(var i = 0; i < otherChanNameX.length; i++){
        if(otherChanNameX[i]){
            var arr = otherChanNameX[i].split(":");
            params += '&' + arr[0] + '=' + arr[1];
        }
    }
    for(var i = 0; i < otherChanNameY.length; i++){
        if(otherChanNameY[i]){
            var arr = otherChanNameY[i].split(":");
            params += '&' + arr[0] + '=' + arr[1];
        }
    }
    for(var i = 0; i < otheryuvEnable.length; i++){
        if(otheryuvEnable[i]){
            var arr = otheryuvEnable[i].split(":");
            params += '&' + arr[0] + '=' + arr[1];
        }
    }
    for(var i = 0; i < otheryuvSkipCount.length; i++){
        if(otheryuvSkipCount[i]){
            var arr = otheryuvSkipCount[i].split(":");
            params += '&' + arr[0] + '=' + arr[1];
        }
    }
    for(var i = 0; i < other_record_enable.length; i++){
        if(other_record_enable[i]){
            var arr = other_record_enable[i].split(":");
            params += '&' + arr[0] + '=' + arr[1];
        }
    }

    params += '&CONFIG_PATH=' + oForm.config_path.value;

    if (null == XMLHttp){
        createXMLHTTP("xml");
    }
    ajaxSendRequest(XMLHttp,'./cgi-bin/set_video_cfg.cgi',params,return_msg);
}

function return_msg(xmlDoc){
    var errorCode = getTextNode(xmlDoc,"code")[0];
    var index = <?php echo $_GET["interface"];?> + 1;
    if(errorCode && errorCode == 0)
        parent.Msg.ok("�ӿ�" + index + "�޸ĳɹ���");
    else
        parent.Msg.fail("�ӿ�" + index + "�޸�ʧ�ܣ�" + (getTextNode(xmlDoc,"desc")[0] || "δ֪����"));
}
</script>
</head>
<body onLoad="setFocus();getInfo()">
<form name="formInput" onSubmit="return checkInput(this)">
  <input type="hidden" name="other_bandwidth" value="" />
  <input type="hidden" name="other_frame_rate" value="" />
  <input type="hidden" name="other_i_frame_rate" value="" />
  <input type="hidden" name="other_frame_delay_count" value="" />
  <input type="hidden" name="other_time_option" value="" />
  <input type="hidden" name="other_time_x" value="" />
  <input type="hidden" name="other_time_y" value="" />
  <input type="hidden" name="other_chan_name" value="" />
  <input type="hidden" name="other_chan_name_x" value="" />
  <input type="hidden" name="other_chan_name_y" value="" />
  <input type="hidden" name="other_yuv_enable" value="" />
  <input type="hidden" name="other_yuv_skip_count" value="" />
  <input type="hidden" name="other_record_enable" value="" />
  <input type="hidden" name="config_path" value="<?php echo $_SERVER["CONFIG_PATH"];?>" />
  <input type="hidden" name="index" value="<?php echo $_GET["interface"];?>" />
  <div class="clear"><span>��ͼˮƽλ�ã�</span>
    <input type="text" name="position" id="position" maxlength="10" />
    pixel </div>
  <div class="clear"><span>������</span>
    <input type="text" name="bandwidth" id="bandwidth" maxlength="10" />
    KBit/s </div>
  <div class="clear"><span>֡�ʣ�</span>
    <input type="text" name="frame_rate" id="frame_rate" maxlength="10" />
    fps(Frames persecond) </div>
  <div class="clear"><span>I֡�ʣ�</span>
    <input type="text" name="i_frame_rate" id="i_frame_rate" maxlength="10" />
    (Frames between two Iframes) </div>
  <div class="clear"><span>��ʱ֡����</span>
    <input type="text" name="frame_delay_count" id="frame_delay_count" maxlength="10" />
    ֡</div>
  <div><span>ʱ����ʾģʽ��</span>
      <select id="timeOption" name="timeOption">
        <option value="" selected="selected"></option>
        <option value="1">��ʾ����ʱ��ģʽ1</option>
        <option value="2">��ʾ����ʱ��ģʽ2</option>
        <option value="3">��ʾ����ʱ��ģʽ3</option>
        <option value="4">��ʾ����ʱ�������ģʽ</option>
      </select>
  </div>
  <div class="clear"><span>ʱ��X���꣺</span>
    <input type="text" name="timeX" id="timeX" maxlength="10" />
  </div>
  <div class="clear"><span>ʱ��Y���꣺</span>
    <input type="text" name="timeY" id="timeY" maxlength="10" />
  </div>
  <div class="clear"><span>ͨ�����ƣ�</span>
    <input type="text" name="chanName" id="chanName" maxlength="30" />
  </div>
  <div class="clear"><span>ͨ������X���꣺</span>
    <input type="text" name="chanNameX" id="chanNameX" maxlength="10" />
  </div>
  <div class="clear"><span>ͨ������Y���꣺</span>
    <input type="text" name="chanNameY" id="chanNameY" maxlength="10" />
  </div>
  <div><span>��¼YUV�ļ���</span>
      <select id="rawEnableOption" name="rawEnableOption">
        <option value="" selected="selected"></option>
        <option value="0">������</option>
        <option value="1">����</option>
      </select>
  </div>
 <div class="clear"><span>YUV��֡����</span>
    <input type="text" name="yuv_frame_skip" id="yuv_frame_skip" maxlength="10" />
    (Skip frames for writing one YUV frame)
 </div>
  <div><span>���ش��棺</span>
      <select id="recordEnableOption" name="recordEnableOption">
        <option value="" selected="selected"></option>
        <option value="0">������</option>
        <option value="1">��������</option>
        <option value="2">ʵʱ����</option>
      </select>
  </div>
  <div class="last">
    <button type="submit">ȷ��</button>
  </div>
</form>
</body>
</html>
