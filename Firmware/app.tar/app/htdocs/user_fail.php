<?php include("header.inc");?>
<title>����ҳ��</title>
<link href="css/golbal.css" rel="stylesheet" type="text/css" />
<link href="css/login.css" rel="stylesheet" type="text/css" />
<!--[if lt IE 7]>
	<script type="text/javascript" src="js/DD_belatedPNG_0.0.8a.js"></script>
    <script type="text/javascript">
    	DD_belatedPNG.fix('img');
    </script>
<![endif]-->
</head>
<body style="background:#F6F6F6;">
<center>
  <table height="100%">
    <tr>
      <td valign="middle"><table>
          <tr>
            <td rowspan="2"><img src="./images/error.png" width="64" height="64" alt=""/></td>
            <td align="center"><h2> �û����Ʋ���ȷ�� </h2></td>
          </tr>
          <tr>
            <td> ��ҳ�潫��<span id="time">3</span>����Զ���ת����¼����, ���� <a href="./index.php">�˴�</a> ��¼��</td>
          </tr>
        </table></td>
    </tr>
  </table>
</center>
</body>
<script type="text/javascript">
var el = document.getElementById("time");
setInterval(function(){
	var val = Number(el.innerHTML);
	if(val <= 1)
		location.replace("./index.php");
	else
		el.innerHTML = val - 1;
},1000)
</script>
</html>