<?php
    header('Content-type: text/xml');
    echo("<?xml version=\"1.0\" encoding=\"GB2312\" ?>");
    echo("<err>");
    $ret=0;
    $errorStr="";
    $ntpServerAddr = strtolower($_POST['ntp_server']);
    $path = "/dev/mtdblock5";
    $pos = "/usr/local/cfg";

    exec("./cgi-bin/mountfs rw $path $pos",$res);
    if($res[0] != "success")
    {
        $ret = -1;
        $errorStr = "����д�����ʧ�ܡ�";
        goto OnExit;
    }
    exec("./cgi-bin/mountfs rw $path $pos",$res);
    $out = fopen($pos.'/ntpd.sh',"w+");
    if($out==FALSE)
    {
        $ret = -2;
        $errorStr = "���ļ�ʧ�ܡ�";
        goto OnExit;
    }
    $res = fwrite($out,"#!/bin/sh\n# ntpd -p address\n# eg. ntpd -p 202.120.2.101\n");
    if($res == FALSE)
    {
        fclose($out);
        $ret = -3;
        $errorStr = "����д�����ʧ�ܡ�";
        goto OnExit;
    }

    if($ntpServerAddr!="")
    {
        $res = fwrite($out,"ntpd -p $ntpServerAddr\n");
        if($res == FALSE)
        {
            fclose($out);
            $ret = -4;
            $errorStr = "����д�����ʧ�ܡ�";
            goto OnExit;
        }
    }

    $res = chmod($pos.'/ntpd.sh',0744);
    if($res == FALSE)
    {
        fclose($out);
        $ret = -5;
        $errorStr = "�޸��ļ�Ȩ��ʧ�ܡ�";
        goto OnExit;
    }

    fclose($out);
    exec("./cgi-bin/mountfs ro $path $pos",$res);

OnExit:
        if ($ret != 0)
            echo("<code>$ret</code><desc>$errorStr</desc>");
        else
            echo("<code>$ret</code>");
        echo("</err>\n");
?>
