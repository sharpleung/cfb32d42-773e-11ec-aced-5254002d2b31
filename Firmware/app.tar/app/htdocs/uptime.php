<?php date_default_timezone_set('Asia/Shanghai');?>
<?php
	$current_time = $_POST["current_time"];
	exec("date -s \"" . $current_time . "\"",$r);
	exec("hwclock --systohc -u",$rr);
	exec("uptime",$res);
	$str = preg_replace ("/(,\s*\d\s*users)?,\s*load.+$/i","",$res[0]);
	if(strlen($str) > 0)
		echo date("Y-m-d ") . $str;
	else
		echo date("Y-m-d H:i:s");
?>
