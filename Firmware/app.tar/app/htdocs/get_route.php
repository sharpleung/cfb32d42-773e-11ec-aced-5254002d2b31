<?php
	header('Content-type:text/xml');
	system("./cgi-bin/get_rt_cfg defaultXml");
?>