<?php session_start();?>
<?php include("check_user.inc");?>
<?php include("header.inc");?>
<?php include("function.php")?>
<?php
	$ntp_server = get_ntp_server();
?>
<title>����ҳ��</title>
<link href="./css/golbal.css" rel="stylesheet" type="text/css" />
<link href="./css/class.css" rel="stylesheet" type="text/css" />
<link href="./css/main.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="./js/common.js"></script>
<script type="text/javascript" src="./js/Notice.js"></script>
<script type="text/javascript" src="./js/Validate.js"></script>
<script type="text/javascript">
var Msg = new Notice();
var XMLHttp = null;//XMLHTTPRequest����


function checkInput(obj){
	var V = new Validate("formInput");

	if(obj.ntp_server.value.length > 0){
		V.checkIp({
			control:"ntp_server",
			checkEmpty:false,
			msg:{
				invalid:"IP��ʽ����"
			},
			err:V.showError
		});
	}
	
	if(V.pass)
		postInfo();
		
	return false;
}

function getInfo(){
	var oForm = document.formInput;
	oForm.ntp_server.value="<?php echo $ntp_server?>"
}

function postInfo(){
	var oForm = document.formInput;
	var params = 'ntp_server=' + oForm.ntp_server.value;
	
	if (null == XMLHttp){
		createXMLHTTP("xml");
	}
	ajaxSendRequest(XMLHttp,'./set_ntpserver.php',params,return_msg);	
}

function return_msg(xmlDoc){
	var errorCode = getTextNode(xmlDoc,"code")[0];
	if(errorCode && errorCode == 0){
		Msg.ok("�޸ĳɹ���");
		setTimeout(function(){
			self.location.href = "ntp.php?name=NTP����";					
		},1500);
	} else {
		Msg.fail("�޸�ʧ�ܣ�" + (getTextNode(xmlDoc,"desc")[0] || "δ֪����"));
	}
		
}

</script>
</head>
<body>
<div id="warper">
  <h1><?php echo $_GET["name"]?></h1>
  <body onLoad="setFocus();getInfo()">
  <form name="formInput" onSubmit="return checkInput(this)">
    <input type="hidden" name="config_path" value="<?php echo $_SERVER["CONFIG_PATH"]?>" />
    <div><span>ntp��������ַ��</span>
      <input type="text" name="ntp_server" id="ntp_server" maxlength="32"/>
    </div>
    <div class="last">
      <button type="submit">ȷ��</button>��<button class="mar_l_r_0" type="button" onClick="history.back(-1)">����</button>
    </div>
  </form>
</div>
</body>
</html>
