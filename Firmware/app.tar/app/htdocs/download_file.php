<?php
    $allow_file = array("rtspserver.conf","video_analyzer.conf","mainboard_type_map.conf","audiod.conf","videod.conf","center.conf","ifboard_type_map.conf","stream_switch.conf","dev.conf","app.taz","wav.tar.gz");
    $file_name = strtolower($_POST['file_name']);
    if(preg_match("/\\.conf$/",$file_name)){   //�ļ�Ϊ*.conf
        $pos = "/usr/local/cfg";
    }
    else if($file_name == "wav.tar.gz"){  //�ļ�Ϊwav.tar.gz
        $pos = "/usr/local/cfg";
    }
    else if($file_name == "app.taz"){  //�ļ�Ϊapp.taz
        $pos = "/app";
    }

    if(in_array($file_name, $allow_file) && file_exists($pos . '/' . $file_name)){
        header("Pragma: public");
        header("Expires: 0");
        header("Content-type: application/octet-stream");
        header("Accept-Ranges: bytes");
        header("Accept-Length: ".filesize($pos . '/' . $file_name));
        header("Content-Disposition: attachment; filename=" . $file_name);

        $file = fopen($pos . '/' . $file_name, "r");
        echo fread($file, filesize($pos . '/' . $file_name));
        fclose($file);
        exit;
    } else {
        header("Content-type:text/html; charset=gb2312");
        echo('<script type="text/javascript">');
        echo 'if(parent.showMsg)';
        echo 'parent.showMsg("fail","����ʧ�ܣ������ڸ��ļ���");';
        echo('</script>');
    }
?>
