<?php
    header("Content-type:text/html; charset=gb2312");
    echo('<script type="text/javascript">');
    $allow_file = array("rtspserver.conf","video_analyzer.conf","mainboard_type_map.conf","audiod.conf","videod.conf","center.conf","ifboard_type_map.conf","stream_switch.conf","dev.conf","web_profile.conf","ifboard_type_map.conf","mainboard_type_map.conf","app.taz","temp","wav.tar.gz");
    $file_name = strtolower($_FILES['file']['name']);

    if(in_array($file_name, $allow_file)) {
        if(preg_match("/\\.conf$/",$file_name)){   //�ϴ��ļ�Ϊ*.conf
            $path = "/dev/mtdblock5";
            $pos = "/usr/local/cfg";
        }
        else if($file_name == "wav.tar.gz"){  //�ϴ��ļ�Ϊwav.tar.gz
            $path = "/dev/mtdblock5";
            $pos = "/usr/local/cfg";
        }
        else if($file_name == "app.taz"){  //�ϴ��ļ�Ϊapp.taz
            $path = "/dev/mtdblock3";
            $pos = "/app";
        }
        else if($file_name == "temp"){  //�ϴ��ļ�Ϊtemp
            $path = "";
            $pos = "/tmp";
        }

        if($path != "") exec("./cgi-bin/mountfs rw $path $pos",$res);
        else $res[0] = "success";
        if($res[0] == "success"){   //mount�ɹ�
            if (move_uploaded_file($_FILES['file']['tmp_name'], $pos . '/' . $file_name)){
                echo 'if(parent.showMsg)';
                echo 'parent.showMsg("ok","�ļ��ϴ��ɹ���");';
            } else {
                echo 'if(parent.showMsg)';
                echo 'parent.showMsg("fail","�ļ��ϴ�ʧ�ܡ�");';
            }
            if($path != "") exec("./cgi-bin/mountfs ro $path $pos",$res);
        } else {
            echo 'if(parent.showMsg)';
            echo 'parent.showMsg("fail","�ļ�д�����ʧ�ܡ�");';
        }
    } else {
        echo 'if(parent.showMsg)';
        echo 'parent.showMsg("fail","�����ϴ����ļ���");';
    }
    echo('</script>');
?>
