<?php session_start();?>
<?php include("check_user.inc");?>
<?php include("header.inc");?>
<title>����ҳ��</title>
<link href="./css/golbal.css" rel="stylesheet" type="text/css" />
<link href="./css/class.css" rel="stylesheet" type="text/css" />
<link href="./css/main.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="./js/common.js"></script>
<script type="text/javascript" src="./js/Notice.js"></script>
<script type="text/javascript" src="./js/Validate.js"></script>
<script type="text/javascript">
var Msg = new Notice();
var XMLHttp = null;//XMLHTTPRequest����

function checkInput(obj){
	var V = new Validate("formInput");

	V.checkIp({
		control:"gateway",
		checkEmpty:true,
		msg:{
			empty:"ȱʡ���ز���Ϊ��",
			invalid:"���ظ�ʽ����"
		},
		err:V.showError
	});

	if(V.pass)
		postInfo();
		
	return false;
}

function getInfo(){
	var num = Math.random();
	if (null == XMLHttp){
		createXMLHTTP("xml");
	}
	ajaxSendRequest(XMLHttp,'./get_route.php?' + num,null,setInfo);
}

function setInfo(xmlDoc){
	var oForm = document.formInput;
	var error = getTextNode(xmlDoc,"code")[0];
	if(error && error == 0){
		var gateway = getNodeAttr(xmlDoc,"default","gateway")[0];
		oForm.gateway.value = gateway;
	} else 
		Msg.fail("���ݻ�ȡʧ�ܣ�" + (getTextNode(xmlDoc,"desc")[0] || "δ֪����"));
}

function postInfo(){
	var oForm = document.formInput;
	var params = 'gateway=' + oForm.gateway.value;
	params += '&CONFIG_PATH=' + oForm.config_path.value;
	
	if (null == XMLHttp){
		createXMLHTTP("xml");
	}
	ajaxSendRequest(XMLHttp,'./cgi-bin/set_rt_cfg.cgi',params,return_msg);	
}

function return_msg(xmlDoc){
	var errorCode = getTextNode(xmlDoc,"code")[0];
	if(errorCode && errorCode == 0)
		Msg.ok("·�������޸ĳɹ���");
	else 
		Msg.fail("·�������޸�ʧ�ܣ�" + (getTextNode(xmlDoc,"desc")[0] || "δ֪����"));
}
</script>
</head>
<body onLoad="getInfo();">
<div id="warper">
  <h1><?php echo($_GET["name"]) ?></h1>
  <form name="formInput" onSubmit="return checkInput(this)">
    <input type="hidden" name="config_path" value="<?php echo $_SERVER["CONFIG_PATH"];?>" />
    <div><span>ȱʡ���أ�</span>
      <input type="text" name="gateway" id="gateway"/>
    </div>
    <div class="last">
      <button type="submit">ȷ��</button>
    </div>
  </form>
</div>
</body>
</html>
