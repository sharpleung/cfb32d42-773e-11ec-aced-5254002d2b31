<?php session_start();?>
<?php include("check_user.inc");?>
<?php include("header.inc");?>
<title>����ҳ��</title>
<link href="./css/golbal.css" rel="stylesheet" type="text/css" />
<link href="./css/class.css" rel="stylesheet" type="text/css" />
<link href="./css/main.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="./js/common.js"></script>
<script type="text/javascript" src="./js/Notice.js"></script>
<script type="text/javascript" src="./js/Validate.js"></script>
<script type="text/javascript">
var Msg = new Notice();
var ALLOW_FILES = ["rtspserver.conf","video_analyzer.conf","mainboard_type_map.conf","audiod.conf","videod.conf","center.conf","ifboard_type_map.conf","stream_switch.conf","dev.conf","web_profile.conf","ifboard_type_map.conf","mainboard_type_map.conf","app.taz","temp","wav.tar.gz"];

function checkInput(obj){
    var V = new Validate("formInput");
    var reg = /[^\\]+$/gi;
    var el = V.oForm.file;
    if(el.value){
        var name = el.value.match(/[^\\]+$/)[0];
        if(!inArray(name.toLowerCase(),ALLOW_FILES)){
            V.showError(el,"�����ϴ����ļ�",V);
            V.pass = false;
        }
    }

    return V.pass;
}

function showMsg(status,text){
    if(Msg)
        Msg[status](text);
}
</script>
</head>
<body>
<div id="warper">
  <h1><?php echo($_GET["name"])?></h1>
  <br />
  <center>
    <form onSubmit="return checkInput(this)" name="formInput" class="clear_patch" method="post" action="upload_file.php" target="upload_file" enctype="multipart/form-data">
      <table>
        <tr>
          <td valign="top">��ѡ����Ҫ�ϴ����ļ���</td>
          <td align="left"><input type="file" name="file" class="file" size="30" /><br /></td>
        </tr>
        <tr height="15"/>
        <tr>
          <td colspan="2" align="center"><button type="submit" class="clear_patch">�ϴ�</button></td>
        </tr>
      </table>
    </form>
  </center>
  <iframe name="upload_file" id="upload_file" class="hide" width="0" height="0"></iframe>
</div>
</body>
</html>
