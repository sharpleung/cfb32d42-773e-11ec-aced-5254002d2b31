<?php session_start();?>
<?php include("check_user.inc");?>
<?php include("header.inc");?>
<?php include("function.php");?>
<?php
	$title = $_GET["name"];
	$ch_type = $_GET["type"];
	$tab_num = get_tab_num("channel:$ch_type");
	$dc = get_tab_detail($ch_type);
?>
<title>����ҳ��</title>
<link href="./css/golbal.css" rel="stylesheet" type="text/css" />
<link href="./css/class.css" rel="stylesheet" type="text/css" />
<link href="./css/main.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="./js/common.js"></script>
<script type="text/javascript" src="./js/Notice.js"></script>
<script type="text/javascript">
var gIndex = 0; //tab���ڵ����
var Msg = new Notice();

function tabScroll(){
	var cIndex = 0;
	var tabNum = <?php echo $tab_num?>;
	var groups = Math.ceil(tabNum/7);
	var fBtn = getClass("first")[0];
	var bBtn = getClass("before")[0];
	var nBtn = getClass("next")[0];
	var lBtn = getClass("last")[0];
	if(fBtn && bBtn && nBtn && lBtn){
		var tabWrapper = getParent(getId("tab"));
		var width = tabWrapper.offsetWidth; 
		fBtn.onclick = function(){
			tabWrapper.scrollLeft = cIndex = 0;
		}
		bBtn.onclick = function(){
			if(cIndex > 0){
				tabWrapper.scrollLeft = width*(--cIndex);
			}
		}
		nBtn.onclick = function(){
			if(cIndex < groups - 1){
				tabWrapper.scrollLeft = width*(++cIndex);
			}
		}
		lBtn.onclick = function(){
			if(cIndex < groups - 1){
				tabWrapper.scrollLeft = width*(groups-1);
				cIndex = groups - 1;
			}
		}
		fBtn = bBtn = lBtn = nBtn = null;
	}
}

window.onload = function(){
	tabScroll();
	var selected_index = 0;
	var els = document.getElementById("tab").getElementsByTagName("li");
	for(var i = 0; i < els.length; i++){
		els[i].onclick = (function(i){
			return function(){
				els[selected_index].className = "";
				selected_index = i;
				this.className = "on";
			}
		})(i)
	}
}

function change(obj){
	location.replace("channel_setting.php?name=ͨ������&type=" + obj.value);
}
</script>
</head>
<body>
<div id="warper">
  <h1><?php echo $title;?></h1>
  <div id="type" class="<?php echo $tab_num > 7?"long":"short";?>">
    <input type="radio" name="type" value="POWER" <?php if($ch_type == "POWER")echo "checked";?> onClick="change(this)"/>��Դ�ɼ�<input type="radio" name="type" value="KEY" <?php if($ch_type == "KEY")echo "checked";?> onClick="change(this)"/>�����ɼ�<input type="radio" name="type" value="CH" <?php if($ch_type == "CH")echo "checked";?> onClick="change(this)"/>�����ɼ�
  </div>
<?php
	if($tab_num > 7){
?>
  <div id="scroll"> <span class="first" title="��һ��">&nbsp;</span> <span class="before" title="��һ��">&nbsp;</span>
    <div>
<?php
	}
?>	
      <ul id="tab" class="clear_fix">
<?php
	for($i = 0; $i < $tab_num; $i++){
		$first_index = $dc->{"0"}["index"];
		$first_title = $dc->{"0"}["title"];
		$index = $dc->{$i}["index"];
		$title = $dc->{$i}["title"];
		if($i == 0)
			echo "<li class='on'><a href='channel_setting_frame.php?type=$ch_type&interface=$index&title=$title' target='frame'>". $title ."</a></li>";
       	else 
			echo "<li><a href='channel_setting_frame.php?type=$ch_type&interface=$index&title=$title' target='frame'>". $title ."</a></li>";     
	}
?>        
      </ul>
<?php
	if($tab_num > 7){
?>      
    </div>
    <span class="next" title="��һ��">&nbsp;</span> <span class="last" title="���һ��">&nbsp;</span> </div>
<?php
	}
?>	    
  <iframe src="channel_setting_frame.php?type=<?php echo $ch_type;?>&interface=<?php echo $first_index;?>&title=<?php echo $first_title;?>" name="frame" id="frame" frameborder="0"></iframe>
</div>
</body>
</html>