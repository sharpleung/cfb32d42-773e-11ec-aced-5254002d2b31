<?php session_start();?>
<?php include("check_user.inc");?>
<?php include("header.inc");?>
<title>����ҳ��</title>
<link href="./css/golbal.css" rel="stylesheet" type="text/css" />
<link href="./css/class.css" rel="stylesheet" type="text/css" />
<link href="./css/main.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="./js/common.js"></script>
<script type="text/javascript" src="./js/Notice.js"></script>
<script type="text/javascript">
var Msg = new Notice();
var XMLHttp = null;

function getInfo(){
	var num = Math.random();
	var params = '&CONFIG_PATH=<?php echo $_SERVER["CONFIG_PATH"];?>';
	if (null == XMLHttp){
		createXMLHTTP("xml");
	}
	ajaxSendRequest(XMLHttp,'./cgi-bin/get_videouser.cgi?' + num,params,setInfo);
}

function setInfo(xmlDoc){
	var error = getTextNode(xmlDoc,"code")[0];
	if(error && error == 0){
		var table = getId("video_user");
		var users = getNode(xmlDoc,"user");
		var l = table.rows.length;
		table.deleteRow(l - 1);
		
		for(var i = 0,len = users.length; i < len; i++){
			var rowIndex = l - 1 + i;
			var row = table.insertRow(rowIndex);
			row.onmouseover = bind(highLight,row,"#FEEE63");
			row.onmouseout = bind(highLight,row,"white");
			var userName = users[i].getAttribute("name");
			var right = users[i].getAttribute("ACCESS_RIGHT");
			var accVideoChan = users[i].getAttribute("ACCESS_VIDEO_CHS").split(" ");
			var accAudioChan = users[i].getAttribute("ACCESS_AUDIO_CHS").split(" ");
			
			//var accVideoChan = users[i].getAttribute("ACCESS_CHS").split(" ");
			//var accAudioChan = "1".split(" ");
			row.insertCell(0).innerHTML = userName;
			row.insertCell(1).innerHTML = right=="RW"?"�ɿ�":"ֻ��";
			row.insertCell(2).innerHTML = accVideoChan;
			row.insertCell(3).innerHTML = accAudioChan;
			row.insertCell(4).innerHTML = "�������";
			row.insertCell(5).innerHTML = '<a href="video_user_mod.php?name=�༭��Ƶ�û�&user=' + userName + '&right=' + right + '&video_access=' + accVideoChan + '&audio_access=' + accAudioChan + '">�༭</a> <a href="javascript:void(0)" onclick="delUser(\'' + userName + '\',this)">ɾ��</a>';
		}
		addUser();
	} else
		Msg.fail("��Ƶ�û����ݻ�ȡʧ�ܣ�" + (getTextNode(xmlDoc,"desc")[0] || "δ֪����"));
}

function delUser(name,obj){
	var tr = getParent(obj,2);
	var index = getIndex(tr);
	var num = Math.random();
	var params = 'CONFIG_PATH=<?php echo $_SERVER["CONFIG_PATH"];?>';
	params += '&name=' + name;
	if (null == XMLHttp){
		createXMLHTTP("xml");
	}
	ajaxSendRequest(XMLHttp,'./cgi-bin/del_videouser.cgi?' + num,params,function(){
		returnFunc(arguments[0],name,index);															 
	});			
}

function returnFunc(xmlDoc,name,index){
	var error = getTextNode(xmlDoc,"code")[0];
	if(error && error == 0){
		Msg.ok("ɾ���û�(" + name + ")�ɹ���");
		var table = getId("video_user");
		table.deleteRow(index);
		addUser();
	} else
		Msg.fail("ɾ���û�(" + name + ")ʧ�ܣ�" + (getTextNode(xmlDoc,"desc")[0] || "δ֪����"));	
}

function highLight(color){
	this.style.backgroundColor = color;	
}

function addUser(){
	var table = getTagName("table")[0];
	var tr = getTagName("tr",table);
	var p = getId("add");
	if(tr.length >= 13){
		p.innerHTML = "";	
	} else{
		if(!p.hasChildNodes()){
			var button = document.createElement("button");
			p.appendChild(button);
			button.onclick = openURL;
			button.appendChild(document.createTextNode("����"));
		}
	}
}

function openURL(){
	self.location.href = "video_user_add.php?name=������Ƶ�û�";	
}

function getIndex(obj){
	var table = getId("video_user");
	for(var i = 0,l = table.rows.length; i < l; i++){
		if(table.rows[i] == obj)
			return i;
	}
}
</script>
</head>
<body onLoad="getInfo()">
<div id="warper">
  <h1><?php echo($_GET["name"])?></h1>
  <div class="status">
    <table cellpadding="0" cellspacing="1" id="video_user">
      <tr>
        <th>�û�����</th>
        <th>���Ȩ��</th>
        <th>��Ͻ��Ƶͨ��</th>
        <th>��Ͻ��Ƶͨ��</th>
        <th>�û�����</th>
        <th>����</th>
      </tr>
      <tr>
        <td colspan="6" align="center">���ڼ�����Ƶ�û���Ϣ...</td>
      </tr>
    </table>
    <p id="add" align="center"></p>
  </div>
</div>
</body>
</html>