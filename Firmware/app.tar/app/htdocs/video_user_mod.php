<?php session_start();?>
<?php include("check_user.inc");?>
<?php include("header.inc");?>
<?php include("function.php")?>
<title>����ҳ��</title>
<link href="./css/golbal.css" rel="stylesheet" type="text/css" />
<link href="./css/class.css" rel="stylesheet" type="text/css" />
<link href="./css/main.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="./js/common.js"></script>
<script type="text/javascript" src="./js/Notice.js"></script>
<script type="text/javascript" src="./js/Validate.js"></script>
<script type="text/javascript">
var Msg = new Notice();
var XMLHttp = null;//XMLHTTPRequest����

function checkInput(obj){
	var V = new Validate("formInput");

	V.checkEmpty({
		control:"right",
		msg:"���Ȩ�޲���Ϊ��",
		err:V.showError
	});
	
	V.checkEmpty({
		control:"video_access",
		msg:"��Ͻ��Ƶͨ������Ϊ��",
		err:V.showError
	});
	
	V.checkEmpty({
		control:"audio_access",
		msg:"��Ͻ��Ƶͨ������Ϊ��",
		err:V.showError
	});
	
	V.checkPassword({
		control:"pwd",
		checkEmpty:true,
		msg:{
			empty:"�û����벻��Ϊ��",
			invalid:"ֻ��Ϊ10λ�����֡���ĸ�Լ��»�����ɵ��ַ�"
		},
		err:V.showError
	});

	if(V.pass)
		postInfo();
		
	return false;
}

function postInfo(){
	var oForm = document.formInput;
	var params = 'name=' + oForm.user.value;
	params += '&ACCESS_RIGHT=' + getVal(oForm.right);
	params += '&ACCESS_VIDEO_CHS=' + getVal(oForm.video_access).join(" ");
	params += '&ACCESS_AUDIO_CHS=' + getVal(oForm.audio_access).join(" ");
	params += '&CONFIG_PATH=' + oForm.config_path.value;
	
	if(!oForm.pwd.disabled){
		params += '&PASSWORD=' + oForm.pwd.value;	
	}
	
	if (null == XMLHttp){
		createXMLHTTP("xml");
	}
	ajaxSendRequest(XMLHttp,'./cgi-bin/mod_videouser.cgi',params,return_msg);	
}

function return_msg(xmlDoc){
	var errorCode = getTextNode(xmlDoc,"code")[0];
	if(errorCode && errorCode == 0){
		Msg.ok("��Ƶ�û��޸ĳɹ���");
		setTimeout(function(){
			self.location.href = "video_user_list.php?name=��Ƶ�û�����";					
		},1500);	
	} else {
		Msg.fail("��Ƶ�û��޸�ʧ�ܣ�" + (getTextNode(xmlDoc,"desc")[0] || "δ֪����"));
	}
}

function clearPwd(bol){
	var el = getId("pwd");
	if(bol){
		el.disabled = false;
		el.value = "";
	} else {
		el.disabled = true;
		el.value = "******";	
	}
}

function getVal(obj){
	var arr = [];
	if(obj.length)
	{
		for(var i = 0; i < obj.length; i++){
			if(obj[i].checked)
				arr.push(obj[i].value);
		}
	}
	else
	{
		if(obj.checked)
			arr.push(obj.value);
	}
	return arr;
}
</script>
</head>
<body>
<?php
	$CONFIG_PATH = $_SERVER["CONFIG_PATH"];
	$title = $_GET["name"];
	$user = $_GET["user"];
	$right = $_GET["right"];
	$video_access = explode(",",$_GET["video_access"]);
	$audio_access = explode(",",$_GET["audio_access"]);
	$video_tabs = get_tab_num("video");
	$audio_tabs = get_tab_num("audio");
?>
<div id="warper">
  <h1><?php echo $title?></h1>
  <form name="formInput" onSubmit="return checkInput(this)">
    <input type="hidden" name="config_path" value="<?php echo $CONFIG_PATH;?>" />
    <div><span>�û����ƣ�</span>
      <input type="text" name="user" id="user" disabled="disabled" value="<?php echo $user?>"/>
    </div>
    <div><span>���Ȩ�ޣ�</span>
      <input class="width_height_auto" type="radio" name="right" value="RW" <?php if($right == "RW") echo "checked"?> />
      �ɿ�
      <input class="width_height_auto" type="radio" name="right" value="R" <?php if($right == "R") echo "checked"?>/>
      ֻ�� </div>
    <div class="clear_fix"><span class="float_l">��Ͻ��Ƶͨ����</span>
      <p class="video">
<?php 
		for($i = 1; $i  <= $video_tabs; $i++){
?>			<input class="width_height_auto" type="checkbox" name="video_access" value="<?php echo $i?>" <?php if(in_array($i,$video_access)) echo "checked"?> />
        ��Ƶ<?php echo $i?>
<?php				
		}
?>      
	</p>
    </div>
    <div class="clear_fix"><span class="float_l">��Ͻ��Ƶͨ����</span>
      <p class="audio">
<?php 
		for($i = 1; $i  <= $audio_tabs; $i++){
?>			<input class="width_height_auto" type="checkbox" name="audio_access" value="<?php echo $i?>" <?php if(in_array($i,$audio_access)) echo "checked"?> />
        ��Ƶ<?php echo $i?>
<?php				
		}
?>      
	</p>
    </div>
    <div><span>�û����룺</span>
      <input type="password" name="pwd" id="pwd" value="******" disabled="disabled"/>
      <input type="checkbox" class="width_height_auto" onClick="clearPwd(this.checked)" />
      �޸� </div>
    <div class="last">
      <button type="submit">ȷ��</button>��<button class="mar_l_r_0" type="button" onClick="history.back(-1)">����</button>
    </div>
  </form>
</div>
</body>
</html>
