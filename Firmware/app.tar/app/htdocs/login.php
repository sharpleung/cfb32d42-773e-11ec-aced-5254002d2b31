<?php
	session_start();
	
	$user = $_POST['user_name'];
	$pwd = $_POST['user_password'];
	$path = $_SERVER["CONFIG_PATH"];
	exec("cat " . $path . "/user.conf",$res);
		
	$str = $res[1];
	$str = preg_replace("/\s+/"," ",$str);
	$arr = explode(" ",$str);
		
	$DEFAULT_USER = $arr[0];
	$DEFAULT_PWD = $arr[1];
		
	if($DEFAULT_USER != $user){
		header("Location:user_fail.php");
	} else if($DEFAULT_PWD != $pwd){
		header("Location:password_fail.php");	
	} else {
		$_SESSION["login"] = "1";
		$_SESSION["user"] = $user;
		header("Location:main.php");
	}
?>