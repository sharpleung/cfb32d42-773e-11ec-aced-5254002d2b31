<?php session_start();?>
<?php include("check_user.inc");?>
<?php include("header.inc");?>
<?php include("function.php");?>
<?php
	$title = $_GET["name"];
	$tab_num = get_tab_num("serial");
?>
<title>����ҳ��</title>
<link href="./css/golbal.css" rel="stylesheet" type="text/css" />
<link href="./css/class.css" rel="stylesheet" type="text/css" />
<link href="./css/main.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="./js/common.js"></script>
<script type="text/javascript" src="./js/Notice.js"></script>
<script type="text/javascript">
var gIndex = 0; //tab���ڵ����
var Msg = new Notice();

function tabScroll(){
	var cIndex = 0;
	var tabNum = <?php echo $tab_num?>;
	var groups = Math.ceil(tabNum/7);
	var fBtn = getClass("first")[0];
	var bBtn = getClass("before")[0];
	var nBtn = getClass("next")[0];
	var lBtn = getClass("last")[0];
	if(fBtn && bBtn && nBtn && lBtn){
		var tabWrapper = getParent(getId("tab"));
		var width = tabWrapper.offsetWidth; 
		fBtn.onclick = function(){
			tabWrapper.scrollLeft = cIndex = 0;
		}
		bBtn.onclick = function(){
			if(cIndex > 0){
				tabWrapper.scrollLeft = width*(--cIndex);
			}
		}
		nBtn.onclick = function(){
			if(cIndex < groups - 1){
				tabWrapper.scrollLeft = width*(++cIndex);
			}
		}
		lBtn.onclick = function(){
			if(cIndex < groups - 1){
				tabWrapper.scrollLeft = width*(groups-1);
				cIndex = groups - 1;
			}
		}
		fBtn = bBtn = lBtn = nBtn = null;
	}
}

window.onload = function(){
	tabScroll();
	var selected_index = 0;
	var els = document.getElementById("tab").getElementsByTagName("li");
	for(var i = 0; i < els.length; i++){
		els[i].onclick = (function(i){
			return function(){
				els[selected_index].className = "";
				selected_index = i;
				this.className = "on";
			}
		})(i)
	}
}
</script>
</head>
<body>
<div id="warper">
  <h1><?php echo $title?></h1>
<?php
	if($tab_num > 7){
?>
  <div id="scroll"> <span class="first" title="��һ��">&nbsp;</span> <span class="before" title="��һ��">&nbsp;</span>
    <div>
<?php
	}
?>	   
  <ul id="tab" class="clear_fix">
<?php
	for($i = 0; $i < $tab_num; $i++){
		if($i == 0)
			echo "<li class='on'><a href='sata_setting_frame.php?interface=$i' target='frame'>����". ($i + 1) ."</a></li>";
       	else 
			echo "<li><a href='sata_setting_frame.php?interface=$i' target='frame'>����". ($i + 1) ."</a></li>";     
	}
?>    
  </ul>
<?php
	if($tab_num > 7){
?>      
    </div>
    <span class="next" title="��һ��">&nbsp;</span> <span class="last" title="���һ��">&nbsp;</span> </div>
<?php
	}
?>	  
  <iframe src="sata_setting_frame.php?interface=0" name="frame" id="frame" frameborder="0"></iframe>
</div>
</body>
</html>
