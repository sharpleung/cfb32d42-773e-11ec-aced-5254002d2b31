<?php
	/*��ȡÿһ�ֽӿڵĽӿ�����(eth/serial/video/sound/channel)
	 *@param {String} $name �ӿ�����
	 *@return {Number} $total �ӿ�����
	**/
	function get_tab_num($name){
		$path = $_SERVER["CONFIG_PATH"];
		$total = 0;
		exec("cat " . $path . "/web_profile.conf",$res);
		for($i = 2; $i < count($res); $i++){
			$str = trim($res[$i]);
			$str = preg_replace("/\s+/"," ",$str);
			$arr = explode(" ",$str);
			if(preg_match("/^$name/i",$arr[0])){
				$total += (int)$arr[1];	
			}
		}
		return $total;
	}
	
	/*����ͨ�����ͻ�ȡͨ������ϸ��Ϣ
	 *@param {String} $name ͨ������
	 *@return {Object} $cd ��ͨ�����͵Ķ��󼯺�
	**/
	function get_tab_detail($name){
		$path = $_SERVER["CONFIG_PATH"];
		class ch_detail{};
		$cd = new ch_detail();
		$num = 0;
		exec("cat " . $path . "/web_profile.conf",$res);
		for($i = 2; $i < count($res); $i++){
			$str = trim($res[$i]);
			$str = preg_replace("/\s+/"," ",$str);
			$arr = explode(" ",$str);
			if(preg_match("/^$name\/\\d+$/i",$arr[0])){
				$index = preg_replace("/^$name\//i","",$arr[0]);
				$title = $arr[1];
				$cd->$num = array("index"=>$index,"title"=>$title);
				$num++;
			}
		}
		
		return $cd;
	}

	/*��ȡntp����˵�ַ
	 *@return {String} $addr �����IP��ַ
	**/
	function get_ntp_server(){
		$path = $_SERVER["CONFIG_PATH"];
		$addr = "";
		exec("cat " . $path . "/ntpd.sh",$res);
		/*for ntpd -p 202.120.2.101*/
		for($i = 0; $i < count($res); $i++){
			$str = trim($res[$i]);
			$arr = explode(" ",$str);
			if($arr[0][0]!='#'&&count($arr)==3)
			{
				$addr = $arr[2];
				break;
			}
		}
		return $addr;
	}	
?>
