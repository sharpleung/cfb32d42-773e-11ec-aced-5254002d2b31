<?php
	header("Content-Type:text/html; charset=gb2312");
	if(file_exists("/dev/videoinfo")){
		$file = fopen("/dev/videoinfo","r") or exit('{"error":"���ݻ�ȡʧ�ܣ�Can not open the file."}');
		$json = "{";
		while(1){
			$val = trim(fgets($file));
			if(strlen($val) == 0)
				break;
			$arr = explode("=",$val);
			$json .= '"' . $arr[0] . '":"' . $arr[1] . '",';
		}
		fclose($file);
		$json = preg_replace("/,$/","}",$json);
		echo $json;
	} else {
		echo('{"error":"���ݻ�ȡʧ�ܣ�File is not exist."}');  
  	}
?>