#!/bin/sh

rmmod musb_hdrc
echo "9 1" >/proc/wdog
