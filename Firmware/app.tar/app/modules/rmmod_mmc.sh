#!/bin/sh

rmmod davinci_mmc.ko
rmmod mmc_block.ko
rmmod mmc_core.ko
