#!/bin/sh

insmod mmc_core.ko
insmod mmc_block.ko
insmod davinci_mmc.ko
