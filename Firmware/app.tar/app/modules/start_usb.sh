#!/bin/sh

echo "9 0" >/proc/wdog
insmod musb_hdrc.ko

