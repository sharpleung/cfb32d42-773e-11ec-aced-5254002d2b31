#!/bin/sh

# --COPYRIGHT--,BSD
#  Copyright (c) $(CPYYEAR), Texas Instruments Incorporated
#  All rights reserved.
#
#  Redistribution and use in source and binary forms, with or without
#  modification, are permitted provided that the following conditions
#  are met:
#
#  *  Redistributions of source code must retain the above copyright
#     notice, this list of conditions and the following disclaimer.
#
#  *  Redistributions in binary form must reproduce the above copyright
#     notice, this list of conditions and the following disclaimer in the
#     documentation and/or other materials provided with the distribution.
#
#  *  Neither the name of Texas Instruments Incorporated nor the names of
#     its contributors may be used to endorse or promote products derived
#     from this software without specific prior written permission.
#
#  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
#  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
#  THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
#  PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
#  CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
#  EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
#  PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
#  OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
#  WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
#  OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
#  EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
# --/COPYRIGHT--
#

# insert cmemk, tell it to occupy physical 120MB-128MB, create
# 20 4K buffers, 10 128K buffers  and two 1MB buffers
#insmod cmemk.ko phys_start=0x87800000 phys_end=0x8ba00000 pools=1x3600000,5x829440,2x1244160,1x40960,2x8192
insmod cmemk.ko phys_start=0x87800000 phys_end=0x8B7FFFFF


# insert dsplinkk
#insmod $DSPLINK_REPO/dsplink/gpp/export/BIN/Linux/DAVINCI/RELEASE/dsplinkk.ko
insmod dsplinkk.ko
rm -f /dev/dsplink
mknod /dev/dsplink c `awk "/dsplink/ {print \\$1}" /proc/devices` 0

# insert lpm
#insmod lpm_dm6446.ko
#rm -f /dev/lpm0
#mknod /dev/lpm0 c `awk "/lpm/ {print \\$1}" /proc/devices` 0

# insert ocvc
#insmod ocvc_dm6446.ko

insmod tvp5146.ko
insmod davinci_capture.ko

#for dma api
rmmod drv.ko 2> /dev/null
insmod drv.ko
rm -f /dev/dev_dma
if [ ! -f /dev/dev_dma ]
then
    major=$(awk '$2=="dev_dma" {print $1}' /proc/devices)
    mknod /dev/dev_dma c ${major} 0
fi

#audio drivers
insmod snd-soc-core.ko
insmod snd-soc-davinci-i2s.ko
insmod davinci-i2s-mcbsp.ko
insmod snd-soc-davinci.ko
insmod snd-soc-tlv320aic3x.ko
insmod snd-soc-tlv320aic23b.ko
insmod snd-soc-evm.ko
insmod hubmmap.ko

major=$(awk '$2=="hubmmap" {print $1}' /proc/devices)
rm -f /dev/1.264
if [ ! -f /dev/1.264 ]
then
    mknod /dev/1.264  c ${major} 1
fi

rm -f /dev/2.264
if [ ! -f /dev/2.264  ]
then
    mknod /dev/2.264  c ${major} 2
fi

rm -f /dev/3.264
if [ ! -f /dev/3.264  ]
then
    mknod /dev/3.264  c ${major} 3
fi

rm -f /dev/4.264
if [ ! -f /dev/4.264  ]
then
    mknod /dev/4.264  c ${major} 4
fi

rm -f /dev/videoinfo
if [ ! -f /dev/videoinfo  ]
then
    mknod /dev/videoinfo  c ${major} 5
fi

rm -f /dev/1.alaw
if [ ! -f /dev/1.alaw  ]
then
    mknod /dev/1.alaw  c ${major} 6
fi

rm -f /dev/1.264.delay
if [ ! -f /dev/1.264.delay ]
then
    mknod /dev/1.264.delay c ${major} 12
fi

rm -f /dev/2.264.delay
if [ ! -f /dev/2.264.delay ]
then
    mknod /dev/2.264.delay c ${major} 13
fi

rm -f /dev/3.264.delay
if [ ! -f /dev/3.264.delay ]
then
    mknod /dev/3.264.delay c ${major} 14
fi

rm -f /dev/4.264.delay
if [ ! -f /dev/4.264.delay ]
then
    mknod /dev/4.264.delay c ${major} 15
fi

rm -f /dev/1.yuv
if [ ! -f /dev/1.yuv ]
then
    mknod /dev/1.yuv c ${major} 16
fi

rm -f /dev/2.yuv
if [ ! -f /dev/2.yuv ]
then
    mknod /dev/2.yuv c ${major} 17
fi

rm -f /dev/3.yuv
if [ ! -f /dev/3.yuv ]
then
    mknod /dev/3.yuv c ${major} 18
fi

rm -f /dev/4.yuv
if [ ! -f /dev/4.yuv ]
then
    mknod /dev/4.yuv c ${major} 19
fi

rm -f /dev/1.264.record
if [ ! -f /dev/1.264.record ]
then
    mknod /dev/1.264.record c ${major} 20
fi

rm -f /dev/2.264.record
if [ ! -f /dev/2.264.record ]
then
    mknod /dev/2.264.record c ${major} 21
fi

rm -f /dev/3.264.record
if [ ! -f /dev/3.264.record ]
then
    mknod /dev/3.264.record c ${major} 22
fi

rm -f /dev/4.264.record
if [ ! -f /dev/4.264.record ]
then
    mknod /dev/4.264.record c ${major} 23
fi

insmod spi_gpio.ko
insmod tkfsv3110_wdog.ko iFeedInterval=500 iMaxNoFeedCount=10 bEnable=1

insmod mmc_core.ko
insmod mmc_block.ko
insmod davinci_mmc.ko

echo "9 0" >/proc/wdog
insmod musb_hdrc.ko
